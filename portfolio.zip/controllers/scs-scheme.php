<?php

return view("scs-scheme.view.php", [
  'heading' => 'The Netmatters <br> Scion Scheme ',
  'subheading' => 'A little bit about myself'
]);