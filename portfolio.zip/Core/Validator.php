<?php

namespace Core;

class Validator {

  public static function required($value) {
    return strlen($value) > 0;
  }

  public static function email($value) {
    return filter_var($value, FILTER_VALIDATE_EMAIL);
  }

  public static function string($value, $min = 1, $max = INF) {
    $value = trim($value);
    return strlen($value) >= $min && strlen($value) <= $max;
  }
}